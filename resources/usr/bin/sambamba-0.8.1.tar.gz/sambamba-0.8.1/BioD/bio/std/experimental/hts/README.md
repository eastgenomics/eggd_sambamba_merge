bio.std.experimental.hts modules are the next generation BAM reading tools.
Some of the functionality aims to replace that of bio modules in this same
repository.
