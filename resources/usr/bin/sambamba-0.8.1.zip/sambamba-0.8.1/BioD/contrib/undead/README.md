
This is a subset copy of D's undead library. This code is considered
obsolete and should be phased out. The original can be found at https://github.com/dlang/undeaD

undeaD
======

Need an obsolete Phobos module? Here they are, back from the dead and upgraded to work with the latest D

